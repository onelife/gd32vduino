# Longduino

## How to use

### PlatformIO
Only need add follow line into `platformio.ini`
```ini 
platform_packages = framework-arduino-gd32v @ https://github.com/sipeed/Longduino.git
```
### Arduino IDE

Add follow url into `Boards Manager URLs`.
```
http://bigbits.oss-cn-qingdao.aliyuncs.com/Arduino_for_GD32V/package_longduino_index.json
```
